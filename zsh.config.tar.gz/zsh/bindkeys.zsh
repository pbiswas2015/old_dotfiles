
###############################################################################
# Fish-like feature - set AFTER zim loads
# History substring search
# up/down arrow - autin override these bindkeys if present
bindkey '^[[A' history-substring-search-up
bindkey '^[[B' history-substring-search-down
# Ctrl+p/Ctrl+n
bindkey '^P'   history-substring-search-up
bindkey '^N'   history-substring-search-down

# accept full ghost autosuggestion with Ctrl+Space or right arrow
bindkey '^ '   autosuggest-accept
bindkey '^[[C' autosuggest-accept

# accept one word of ghost autosuggestion at a time with Ctrl+up
bindkey '^[[1;5A' forward-word

# Word jump with Ctrl+Arrow
# Ctrl+Right
bindkey '^[[1;5C' forward-word
# Ctrl+Left
bindkey '^[[1;5D' backward-word

###############################################################################
# Standard tab complete (default, shown for context)
# Tab
bindkey '^I'     complete-word

## Double Tab - fzf completion
bindkey '^I^I'  fzf-completion

# Shift+Tab — cycle completions BACKWARDS (very useful in menus)
bindkey '^[[Z'   reverse-menu-complete

# Alt+/  — complete from all possible matches, show list immediately
bindkey '^[/'    complete-word

# Ctrl+X Ctrl+F — complete filename specifically (bypass other completers)
bindkey '^X^F'   _next_tags

# Ctrl+R = opens fzf for history search
bindkey '^R' fzf-history-widget
