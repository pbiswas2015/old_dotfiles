
# enable zsh's built-in profiler
# zmodload zsh/zprof

###############################################################################
# my zshrc
export ZDOTDIR="${HOME}/.config/zsh"
if [[ -f ${ZDOTDIR}/.zshrc.private ]]; then
  source ${ZDOTDIR}/.zshrc.private
fi

###############################################################################
# prints timing report on every shell start
# zprof
