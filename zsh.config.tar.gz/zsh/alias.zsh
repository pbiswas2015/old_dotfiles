alias sal='source ${ZDOTDIR}/.alias.zsh'
alias nal='nvim ${ZDOTDIR}/.alias.zsh'
alias val='nvim ${ZDOTDIR}/.alias.zsh'

#############################################################
# clear zsh cache
function zsh-cache-clear() {
  # local disable of rm * protection
  setopt local_options NO_RM_STAR_WAIT NO_RM_STAR_SILENT
  \rm -rf "${HOME}/.zsh/cache/"
  mkdir -p "${HOME}/.zsh/cache"
  \rm -f "${HOME}/.zcompdump*"
  exec zsh
}

###############################################################################
# use lazyzim nvim distro
export NVIM_APPNAME=nvim-lazyvim
alias nvim="NVIM_APPNAME=nvim-lazyvim nvim"

alias n='nvim -p'
alias cn='nvim --clean'
alias ndiff='nvim -d'

alias v='vim -p'
alias vv='view -p'

# alias gv='gvim -p'
# alias gb='gvim -p -u ~/.vimrc.barebone'
# alias gvb='gview -p -u ~/.vimrc.barebone'
# alias gn='gvim -p -u none'
# alias gvn='gview -p -u none'

###############################################################################
# ls
# alias ls='ls --color=auto'
# alias lt='ls -ltra'
# alias ll='ls -lrt'
# alias l1='ls -1rt'
# alias lg='ls -lrta | grep -i'

alias ls='eza --icons --group-directories-first'
alias l1="eza -1 -a --group-directories-first"
alias l1f="eza -1 -a -f"
alias l1d="eza -1 -a -D"

alias la='eza -a --icons --group-directories-first'
alias ll='eza -la --icons -s time'

alias lt='eza --tree --icons --level=2'
alias llt="eza -1 -a --icons --tree --git-ignore"
alias llr="eza -lag --recurse --icons --git-ignore"

alias lg='ll | rg -i'

# Long format, largest file size last
alias lk='eza -la --icons -s size'
# Long format, newest modification time last
alias lt='eza -la --icons -s modified'
# Long format, newest status change (ctime) last
alias lc='eza -la --icons -s changed'

###############################################################################

alias tree='tree -C'

alias grep='grep --color=auto'
alias egrep='egrep --color=auto'
alias fgrep='fgrep --color=auto'

alias diff='diff --color=auto'


alias c='clear'
alias cl='clear;ls'

alias pf='readlink -f'
alias rp='readlink -f'

# always create parents, verbose
alias mkdir='mkdir -pv'

alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'
alias ..2='cd ../..'
alias ..3='cd ../../..'
alias ..4='cd ../../../..'
alias ..5='cd ../../../../..'
alias ..6='cd ../../../../../..'
# cd to previous dir
alias -- -='cd -'

# Process / system
#alias ps='procs'
alias psa='ps aux | grep -v grep'
alias psg='ps aux | grep -i'      # usage: psg python
alias topcpu='ps aux --sort=-%cpu | head -11'
alias topmem='ps aux --sort=-%mem | head -11'
alias ports='ss -tulnp'           # listening ports
alias myip='curl -s ifconfig.me'

# Disk
#alias du='dust'
#alias df='duf'
alias df='df -hT --exclude-type=tmpfs --exclude-type=devtmpfs'
alias du='du -sh * | sort -rh'    # sorted by size
alias duh='du -h --max-depth=1 | sort -rh'

# Quick file search
alias fd='fd --hidden --follow'
# ff pattern [dir]
ff() { fd --type f --hidden "$1" "${2:-.}" }
# fzf into dir
fcd() { cd "$(fd --type d "$1" | fzf)" }

# Extract anything
extract() {
  case $1 in
    *.tar.bz2) tar xjf $1    ;;
    *.tar.gz)  tar xzf $1    ;;
    *.tar.xz)  tar xJf $1    ;;
    *.zip)     unzip $1      ;;
    *.gz)      gunzip $1     ;;
    *.bz2)     bunzip2 $1    ;;
    *.7z)      7z x $1       ;;
    *.rar)     unrar x $1    ;;
    *)         echo "'$1' cannot be extracted" ;;
  esac
}

alias .='pwd'
alias p="pwd"
alias h='history'
alias h25='history 25'
alias tk='tkdiff'

# dust
alias du1='dust -r --threads 2 -d 1'
alias du2='dust -r --threads 2 -d 2'
alias du1r='dust --threads 2 -d 1'
alias du2r='dust --threads 2 -d 2'

###############################################################################
# conda
alias ca='conda activate'
alias cda='conda deactivate'
alias cel='conda env list'
alias mel='mamba env list'

###############################################################################
# git
#alias gs='git status -sb'
#alias gd='git diff'
#alias ga='git add'
#alias gc='git commit'
#alias gp='git push'
#alias gl='git lg'
#alias gco='git checkout'
#alias gcl='git clone'
#alias gll='git log --graph --pretty=oneline --abbrev-commit'
alias g='git'
alias gst='git status -sb'
#alias glog='git log --oneline --graph --decorate --all'
alias glog="git log --graph --format=format:'%C(bold blue)%h%C(reset) - %C(bold green)(%ar)%C(reset) %C(white)%an%C(reset)%C(bold yellow)%d%C(reset) %C(dim white)- %s%C(reset)' --all"
alias gdiff='git diff --word-diff'
alias gstash='git stash list'

# fzf-powered git branch switcher
# gco() {
#   local branch
#   branch=$(git branch --all | grep -v HEAD | fzf --height 40% \
#     --preview 'git log --oneline --graph {1}' \
#     | sed 's/remotes\/origin\///' | xargs)
#   [[ -n "$branch" ]] && git checkout "$branch"
# }

# fzf-powered git log browser
gshow() {
  git log --oneline --color=always | fzf \
    --ansi \
    --preview 'git show --color=always {1}' \
    --bind 'ctrl-u:preview-page-up' \
    --bind 'ctrl-d:preview-page-down' \
    --bind 'enter:execute(git show --color=always {1} | less -R)'
}

###############################################################################
# chezmoi
alias cz='chezmoi'
alias czcd='cd ~/.local/share/chezmoi/'
alias cza='chezmoi add'
alias czd='chezmoi diff'
# espace ^ as zsh uses extended globbing
alias czdf='chezmoi diff | rg \^diff'
alias cze='chezmoi edit'
alias czs='chezmoi status'

# pull + apply latest from git
alias czu='chezmoi update'

function czp() {
  
  local comment=""
  local output
  local exit_code

  local cz_git_dir="${HOME}/.local/share/chezmoi"
  
  echo "cd $cz_git_dir && git pull"
  output=$(cd $cz_git_dir && git pull);
  exit_code=$?
  if [[ $exit_code -eq 0 ]]; then
    echo "$output"
  else
    echo "$output"
    return $exit_code
  fi
  if [[ $# -eq 0 ]]; then
    comment="update dotfiles"
  else
    comment="$1"
  fi
  echo "cd $cz_git_dir && git add --all && git commit -m \"$comment\" && git push"
  cd $cz_git_dir && git add --all && git commit -m $comment && git push

}

###############################################################################
# Jupyter
alias jl='jupyter lab --no-browser &'
alias jn='jupyter notebook --no-browser &'

###############################################################################
# Python shortcuts
alias py='python'
alias ipy='ipython'
# safety net
alias pip='pip --require-virtualenv'

#############################################################
# Quick venv workflow
# create venv
alias ve='python -m venv .venv'
# activate
alias va='source .venv/bin/activate'
# deactivate
alias vd='deactivate'
# install deps
alias vr='pip install -r requirements.txt'

#############################################################
# functions
#############################################################
# bak - backup a file

function bak() {
  # Usage:
  #   bak file.txt      --> file.txt.2026-03-08_14-23-01.bak
  #   bak /etc/hosts    --> /etc/hosts.2026-03-08_14-23-01.bak

  # check arguments
  if [[ $# -eq 0 ]]; then
    echo "Usage: bak <file>" >&2
    return 1
  fi

  local src="$1"

  # checl if file exits and is regular file
  if [[ ! -e "$src" ]]; then
    echo "bak: '$src' does not exist" >&2
    return 1
  fi

  if [[ ! -f "$src" ]]; then
    echo "bak: '$src' is not a regular file (use cp -r for directories)" >&2
    return 1
  fi

  # create backup
  local timestamp
  timestamp=$(date +%Y-%m-%d_%H-%M-%S)

  local dest="${src}.${timestamp}.bak"

  # preserves: permissions, ownership, timestamps
  cp -p "$src" "$dest"

  if [[ $? -eq 0 ]]; then
    echo "✅ Backup created: $src → $dest"
  else
    echo "bak: failed to copy '$src'" >&2
    return 1
  fi
}

#############################################################
# hs - history search
unalias hs 2>/dev/null
function hs() {
  if [ $# == 0 ]; then
    # do nothing
    echo "Usage: hs <search_string_in_history>"
  else
    history | rg "${1}"
  fi
}

#############################################################
# zhs - zsh history file search
function zhs() {
  if [ $# == 0 ]; then
    # do nothing
    echo "Usage: zhs <search_string_in_history>"
  else
    rg "${1}" ~/.zsh_history
  fi
}

#############################################################
# pf - get file realpath with fzf
unalias pf 2>/dev/null
function pf() {
  # No arguments
  if [ $# == 0 ]; then
    if [ -z "$TMUX" ]; then
      fzf_cmd="fzf"
    else
      fzf_cmd="fzf-tmux"
    fi
    fval=$(fd -E .snapshot/ -H | $fzf_cmd)
    ret_status=$?
    if [ $ret_status != 0 ]; then
      return
    fi
    abs_path=$(readlink -f "$fval")
  else
    abs_path=$(readlink -f "${1}")
  fi
  echo " ${abs_path}"
}

#############################################################
# remmove nvim config
unalias remove_nvim_config 2>/dev/null
function remove_nvim_config() {
  if [ $# == 0 ]; then
    echo "Removing default nvim config"
    rm -rf ~/.config/nvim
    rm -rf ~/.local/state/nvim
    rm -rf ~/.local/share/nvim
    rm -rf ~/.cache/nvim
  else
    echo "Removing nvim config for $1"
    rm -rf "${HOME}/.config/nvim-$1"
    rm -rf "${HOME}/.local/state/nvim-$1"
    rm -rf "${HOME}/.local/share/nvim-$1"
    rm -rf "${HOME}/.cache/nvim-$1"
  fi
}

#############################################################
# y - open yazi
unalias y 2>/dev/null
function y() {
  local tmp="$(mktemp -t "yazi-cwd.XXXXXX")" cwd
  command yazi "$@" --cwd-file="$tmp"
  IFS= read -r -d '' cwd <"$tmp"
  [ "$cwd" != "$PWD" ] && [ -d "$cwd" ] && builtin cd -- "$cwd"
  rm -f -- "$tmp"
}

#############################################################
# pg - search for process by name
unalias pg 2>/dev/null
function pg() {
  ps -aux | grep -v " grep " | grep -P -i "^USER|${1}"
}

#############################################################
# fn - get fd like behavious with find
unalias fn 2>/dev/null
function fn() {
  if [[ $2 != '' ]]; then
    find "$2" | grep -P -i "$1"
  else
    find ./ | grep -P -i "$1"
  fi
}

#############################################################
# mkcd - create and cd to directory
function mkcd() {
  mkdir -p "$1"
  cd "$1" || return
  echo " $(pwd)"
}

#############################################################
# _fasd_add_entry - add entry to fasd db file
unalias _fasd_add_entry 2>/dev/null
function _fasd_add_entry() {
  fasd_path=$(which fasd)
  if [[ -f "$fasd_path" ]]; then
    fasd --add "$@"
  fi
}

#############################################################
# cdf - fuzzy cd into directory
unalias cdf 2>/dev/null
function cdf() {
  cur_dir=$(pwd)
  fzf_cmd="fzf-tmux"
  if [[ $1 != '' ]]; then
    fval=$(fd -E .snapshot/ -t d -H -d "$1" | $fzf_cmd)
  else
    fval=$(fd -E .snapshot/ -t d -H | $fzf_cmd)
  fi
  ret_status=$?
  if [ $ret_status == 0 ]; then
    cd "$fval" || return
  else
    cd "$cur_dir" || return
  fi
  echo " $(pwd)"
  ls
}
alias cd1='cdf 1'
alias cd2='cdf 2'
alias cd3='cdf 3'
alias cd4='cdf 4'

#############################################################
# gf - fuzzy open files in gvim
unalias gf 2>/dev/null
function gf() {
  if [ -z "$TMUX" ]; then
    fzf_cmd="fzf -m"
  else
    fzf_cmd="fzf-tmux -m"
  fi
  if [[ $1 != '' ]]; then
    fval=$(fd -E .snapshot/ -t f -H -d "$1" | $fzf_cmd -preview 'bat --color=always --style=numbers --line-range=:500 {}') || return
  else
    fval=$(fd -E .snapshot/ -t f -H | $fzf_cmd --preview 'bat --color=always --style=numbers --line-range=:500 {}') || return
  fi
  echo "gvim $fval"
  _fasd_add_entry "$fval"
  g "$fval"
}
alias gf1='gf 1'
alias gf2='gf 2'
alias gf3='gf 3'
alias gf4='gf 4'

#############################################################
# nf - fuzzy open files in nvim
unalias nf 2>/dev/null
function nf() {
  if [ -z "$TMUX" ]; then
    fzf_cmd="fzf -m"
  else
    fzf_cmd="fzf-tmux -m"
  fi
  if [[ $1 != '' ]]; then
    fval=$(fd -E .snapshot/ -t f -H -d "$1" | $fzf_cmd --preview 'bat --color=always --style=numbers --line-range=:500 {}') || return
  else
    fval=$(fd -E .snapshot/ -t f -H | $fzf_cmd --preview 'bat --color=always --style=numbers --line-range=:500 {}') || return
  fi
  echo "nvim $fval"
  _fasd_add_entry "$fval"
  n "$fval"
}
alias nf1='nf 1'
alias nf2='nf 2'
alias nf3='nf 3'
alias nf4='nf 4'

#############################################################
# vf - fuzz view files
unalias vf 2>/dev/null
function vf() {
  if [ -z "$TMUX" ]; then
    fzf_cmd="fzf"
  else
    fzf_cmd="fzf-tmux"
  fi
  if [[ $1 != '' ]]; then
    fval=$(fd -E .snapshot/ -t f -H -d "$1" | $fzf_cmd -preview 'bat --color=always --style=numbers --line-range=:500 {}') || return
  else
    fval=$(fd -E .snapshot/ -t f -H | $fzf_cmd -preview 'bat --color=always --style=numbers --line-range=:500 {}') || return
  fi
  echo "view $fval"
  _fasd_add_entry "$fval"
  v "$fval"
}
alias vf1='vf 1'
alias vf2='vf 2'
alias vf3='vf 3'
alias vf4='vf 4'

#############################################################
# lf - fuzzy list directories/files
unalias lf 2>/dev/null
function lf() {
  cur_dir=$(pwd)
  if [ -z "$TMUX" ]; then
    fzf_cmd="fzf"
  else
    fzf_cmd="fzf-tmux"
  fi
  #fval=$(fd -E .snapshot/ -H -L | $fzf_cmd)
  fval=$(fd -H -L | fzf --prompt 'All> ' \
    --header 'CTRL-D: Directories / CTRL-F: Files' \
    --bind 'ctrl-d:change-prompt(Directories>)+reload(fd -t d -H -L)' \
    --bind 'ctrl-f:change-prompt(Files>)+reload(fd -t f -H -L)' \
    --preview '[ -f {} ] && bat --color=always --style=numbers --line-range=:500 {} || tree -C {}')
  for var in $fval; do
    echo "ll $var"
    ll "$var"
  done
}

#############################################################
# rgf - old version
unalias rgf_old 2>/dev/null
function rgf_old() {
  # 1. Search for text in files using ripgrep
  # 2. Interactively narrow down the list using fzf
  # 3. Open the file in nvim
  rg --color=always --line-number --no-heading --smart-case "${*:-}" |
    fzf --ansi --height 90% \
      --color "hl:-1:underline,hl+:-1:underline:reverse" \
      --delimiter : \
      --preview 'bat --color=always {1} --style=numbers --line-range=:500 --highlight-line {2}' \
      --preview-window 'up,60%,border-bottom,+{2}+3/3,~3' \
      --bind 'enter:become(nvim {1} +{2})'
}

#############################################################
# rgf - search for files and open them
unalias rgf 2>/dev/null
function rgf() {
  # Two-phase filtering with Ripgrep and fzf
  #
  # 1. Search for text in files using Ripgrep
  # 2. Interactively restart Ripgrep with reload action
  #    Switch between Ripgrep launcher mode (CTRL-R) and fzf filtering mode (CTRL-F)
  # 3. Open the file in Vim
  rm -f /tmp/rg-fzf-{r,f}
  RG_PREFIX="rg --column --line-number --no-heading --color=always --smart-case "
  INITIAL_QUERY="${*:-}"
  fzf --ansi --disabled --height 90% --query "$INITIAL_QUERY" \
    --bind "start:reload($RG_PREFIX {q})+unbind(ctrl-r)" \
    --bind "change:reload:sleep 0.1; $RG_PREFIX {q} || true" \
    --bind "ctrl-f:unbind(change,ctrl-f)+change-prompt(2. fzf> )+enable-search+rebind(ctrl-r)+transform-query(echo {q} > /tmp/rg-fzf-r; cat /tmp/rg-fzf-f)" \
    --bind "ctrl-r:unbind(ctrl-r)+change-prompt(1. ripgrep> )+disable-search+reload($RG_PREFIX {q} || true)+rebind(change,ctrl-f)+transform-query(echo {q} > /tmp/rg-fzf-f; cat /tmp/rg-fzf-r)" \
    --color "hl:-1:underline,hl+:-1:underline:reverse" \
    --prompt '1. ripgrep> ' \
    --delimiter : \
    --header '╱ CTRL-R (ripgrep mode) ╱ CTRL-F (fzf mode) ╱' \
    --preview 'bat --color=always {1} --style=numbers --line-range=:500 --highlight-line {2}' \
    --preview-window 'up,60%,border-bottom,+{2}+3/3,~3' \
    --bind 'enter:become(nvim {1} +{2})'
}

#############################################################
# rgc - search for count of expression in each file and choose file to open
unalias rgc 2>/dev/null
function rgc() {
  rm -f /tmp/rg-fzf-{r,f}
  RG_PREFIX="rg -c --color=always --smart-case"
  INITIAL_QUERY="${*:-}"
  : | fzf --ansi --disabled --height 90% --query "$INITIAL_QUERY" \
    --bind "start:reload($RG_PREFIX {q})+unbind(ctrl-r)" \
    --bind "change:reload:sleep 0.1; $RG_PREFIX {q} || true" \
    --bind "ctrl-f:unbind(change,ctrl-f)+change-prompt(2. fzf> )+enable-search+rebind(ctrl-r)+transform-query(echo {q} > /tmp/rg-fzf-r; cat /tmp/rg-fzf-f)" \
    --bind "ctrl-r:unbind(ctrl-r)+change-prompt(1. ripgrep> )+disable-search+reload($RG_PREFIX {q} || true)+rebind(change,ctrl-f)+transform-query(echo {q} > /tmp/rg-fzf-f; cat /tmp/rg-fzf-r)" \
    --color "hl:-1:underline,hl+:-1:underline:reverse" \
    --prompt '1. ripgrep> ' \
    --delimiter : \
    --header '╱ CTRL-R (ripgrep mode) ╱ CTRL-F (fzf mode) ╱' \
    --preview 'bat --color=always {1} --style=numbers --line-range=:500' \
    --preview-window 'up,60%,border-bottom,+{2}+3/3,~3' \
    --bind 'enter:become(nvim {1})'
}

#############################################################
# ff - search through fasd file list and filer with fzf to open in nvim
unalias ff 2>/dev/null
function ff() {
  if [ $# == 0 ]; then
    file_list=$(fasd -l -R -f)
    search_expr=""
  else
    search_expr=$1
  fi
  fasd -l -R -f | fzf --ansi --height 90% \
    --query "$search_expr" \
    --preview 'bat --color=always {1} --style=numbers --line-range=:500' \
    --bind 'enter:become(nvim {1})' \
    --bind 'up:preview-half-page-up,down:preview-half-page-down'
}

#############################################################
# cpf - fuzzy select source file, fuzzy select destination and copy
unalias cpf 2>/dev/null
function cpf() {
  local src_filedir=$(fasd -a -l -r "$1" | fzf)
  local dest_dir=$(fasd -d -l -r "$2" | fzf)
  if [[ $src_filedir != '' ]]; then
    if [[ $dest_dir != '' ]]; then
      cp -rfp "$src_file" "$dest_dir"
      echo "cp -rfp $src_filedir $dest_dir"
      cd "$dest_dir" || return
      pwd
    fi
  fi
}

#############################################################
# cpd - fuzzy select source file, give destination and copy
unalias cpd 2>/dev/null
function cpd() {
  local src_filedir=$(fasd -a -l -r "$1" | fzf)
  local dest_dir=$2
  if [[ $src_filedir != '' ]]; then
    if [[ $dest_dir != '' ]]; then
      cp -rfp "$src_file" "$dest_dir"
      echo "cp -rfp $src_filedir $dest_dir"
      cd "$dest_dir" || return
      pwd
    fi
  fi
}

#############################################################
# sync_completions - sync brew and custom bash completions
function sync_completions() {
  local user_dir="${HOME}/.local/share/bash-completion/completions"
  local custom_dir="${HOME}/.local/share/bash-completion/custom_completions"
  local system_dir="/usr/share/bash-completion/completions"
  local skipped=()
  mkdir -p "$user_dir"
  # compat/legacy first, modern share/ wins on collision
  local brew_dirs=(
    "/home/linuxbrew/.linuxbrew/etc/bash_completion.d"
    "/home/linuxbrew/.linuxbrew/share/bash-completion/completions"
  )
  for brew_dir in "${brew_dirs[@]}"; do
    [[ -d "$brew_dir" ]] || continue
    for src in "$brew_dir"/*; do
      local name="${src##*/}"
      if [[ -e "$system_dir/$name" ]]; then
        # System apt version exists — skip, don't override
        skipped+=("$name")
      else
        ln -sf "$src" "$user_dir/$name"
      fi
    done
  done

  echo "✅ Synced $(ls "$user_dir" | wc -l) brew completions to $user_dir"
  if [[ ${#skipped[@]} -gt 0 ]]; then
    echo "⏭️  Skipped ${#skipped[@]} brew completions (apt version takes priority)"
  fi

  if [[ -d "$custom_dir" ]]; then
    for src in "$custom_dir"/*; do
      local name="${src##*/}"
      ln -sf "$src" "$user_dir/$name"
    done
  fi

  echo "✅ Synced $(ls "$custom_dir" | wc -l) custom completions to $user_dir"

}

#############################################################
# note - quick note from terminal
function note() {
  export OBSIDIAN_ROOT="/mnt/f/OneDrive/Data/pbiswas_data/notes/pb_vault/"
  echo "## $(date '+%Y-%m-%d %H:%M') — $1" >>${OBSIDIAN_ROOT}/scratch_cli.md
  ${EDITOR:-nvim} ~/notes/scratch_cli.md
}

#############################################################
# ftag - fuzzy search and jump to tag
function ftag() {
  local tag
  tag=$(cat tags 2>/dev/null \
    | grep -v '^!' \
    | awk -F'\t' '{print $1"\t"$2"\t"$3}' \
    | fzf --prompt="tag> " \
          --preview 'bat --color=always {2}' \
    | awk '{print $1}')
  [[ -n "$tag" ]] && nvim -t "$tag"
}

#############################################################
