
###############################################################################
# completion tuning
# (zim loads compinit - just add zstyle tweaks here)

zstyle ':completion:*' menu select
# fuzzy: partial word matching
zstyle ':completion:*' matcher-list \
  'm:{a-zA-Z}={A-Za-z}' \
  'r:|[._-]=* r:|=*' \
  'l:|=* r:|=*'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*:descriptions' format '[%d]'
zstyle ':completion:*:warnings' format 'No matches: %d'
# group by type
zstyle ':completion:*' group-name ''
zstyle ':completion:*' squeeze-slashes true
# sudo completions
zstyle ':completion::complete:*' gain-privileges 1

# shared cache directory for all
mkdir -p "$HOME/.zsh/cache"
zstyle ':completion::complete:*' cache-path "$HOME/.zsh/cache"

# cache completions
zstyle ':completion::complete:conda:*'    use-cache 1
zstyle ':completion::complete:mamba:*'    use-cache 1
zstyle ':completion::complete:pip:*'      use-cache 1
zstyle ':completion::complete:apt:*'      use-cache 1
zstyle ':completion::complete:ssh:*'      use-cache 1
zstyle ':completion::complete:git:*'      use-cache 1

# for conda completions
# display subcommand completion in groups
zstyle ":conda_zsh_completion:*" use-groups true
# display unnamed environments and prefixes of environments
zstyle ":conda_zsh_completion:*" show-unnamed true
# display environments autocompletion sorted in creation order
zstyle ":conda_zsh_completion:*" sort-envs-by-time true

# To forcefully clean the completion cache, look in '${ZDOTDIR}/.zcompcache' and remove
# file starting with 'conda_'. And delete: 'rm ${ZDOTDIR}/.zcompdump*'.

# Ignore all Windows executable extensions in completion
zstyle ':completion:*' ignored-patterns \
  '*.exe' '*.dll' '*.com' '*.bat' '*.cmd' '*.msi' '*.ps1'

# Also hide them from file completion:
fignore=(.exe .dll .com .bat .cmd .msi .ps1)
