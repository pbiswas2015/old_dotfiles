###############################################################################
# plugins
###############################################################################
# sane zsh defaults environment options
source ${ZDOTDIR}/plugins/environment.plugin.zsh

# Applies correct bindkeys for input events.
# Better input: Ctrl+W deletes word, alt-. inserts last arg, etc.
zsh-defer source ${ZDOTDIR}/plugins/input.plugin.zsh

# git aliases: gst, gco, glog etc
zsh-defer source ${ZDOTDIR}/plugins/git.plugin.zsh

# terminal window title
zsh-defer source ${ZDOTDIR}/plugins/termtitle.plugin.zsh

# coloured ls, grep, less
source ${ZDOTDIR}/plugins/utility.plugin.zsh

# archive/unarchive: `aunpack file.tar.gz`, `apack out.zip dir/`
zsh-defer source ${ZDOTDIR}/plugins/archive.plugin.zsh

###############################################################################
# utilities
# reminds you of existing aliases
zsh-defer source ${ZDOTDIR}/plugins/zsh-you-should-use.plugin.zsh

# auto-close brackets/quotes
zsh-defer source ${ZDOTDIR}/plugins/autopair.plugin.zsh

# wfxr/forgit — fzf-powered git commands
# glo  →  fzf git log
# gd   →  fzf git diff
# ga   →  fzf git add
# gco  →  fzf git checkout
zsh-defer source ${ZDOTDIR}/plugins/forgit.plugin.zsh

###############################################################################
# Completion

# calls compinit
source ${ZDOTDIR}/plugins/completion.plugin.zsh

###############################################################################
# fish like plugins - order is critical

# ghost text suggestions
source ${ZDOTDIR}/plugins/zsh-autosuggestions.zsh

# syntax highlighting, must be sourced after completion
source ${ZDOTDIR}/plugins/fast-syntax-highlighting/fast-syntax-highlighting.plugin.zsh

# History substring search (↑↓ filter by typed prefix)
# MUST be last
source ${ZDOTDIR}/plugins/zsh-history-substring-search.zsh

# Add the following to your ~/.zshrc to boost performance:
# ZSH_AUTOSUGGEST_MANUAL_REBIND=1
