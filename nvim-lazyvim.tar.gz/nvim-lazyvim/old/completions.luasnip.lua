-- remove below line to enable plugin
if true then
  return {}
end

return {
  {
    "saghen/blink.cmp",
    dependencies = {
      "L3MON4D3/LuaSnip",
    },
    enabled = true,
    opts = {
      keymap = {
        preset = "super-tab",
      },
      snippets = {
        expand = function(snippet)
          require("luasnip").lsp_expand(snippet)
        end,
        active = function(filter)
          if filter and filter.direction then
            return require("luasnip").jumpable(filter.direction)
          end
          return require("luasnip").in_snippet()
        end,
        jump = function(direction)
          require("luasnip").jump(direction)
        end,
      },
      sources = {
        -- enable = true, # old config
        default = { "lsp", "path", "snippets", "buffer" },
        providers = {
          buffer = {
            opts = {
              get_bufnrs = vim.api.nvim_list_bufs,
            },
          },
        },
      },
    },
  },

  -- Snippet collection for many languages
  {
    "rafamadriz/friendly-snippets",
  },

  -- LuaSnip: snippet engine
  {
    "L3MON4D3/LuaSnip",
    dependencies = { "rafamadriz/friendly-snippets" },
    enabled = true,
    version = "v2.*",
    build = "make install_jsregexp",
    opts = {
      history = true,
      delete_check_events = "TextChanged",
    },
    config = function()
      require("luasnip.loaders.from_vscode").lazy_load()
    end,
  },

  -- mini.snippets: lightweight snippet engine (alternative/complement to LuaSnip)
  {
    "nvim-mini/mini.snippets",
    enabled = false,
  },
}
