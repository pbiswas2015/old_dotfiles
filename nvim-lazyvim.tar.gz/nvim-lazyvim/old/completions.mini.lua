-- remove below lines to enable plugin
if true then
  return {}
end

return {

    -- supermaven: fast inline ghost-text completions
  {
    "supermaven-inc/supermaven-nvim",
    enabled = false,
  }
  -- blink.cmp uses mini_snippets preset
  {
    "saghen/blink.cmp",
    enabled = true,
    opts = function(_, opts)
      -- snippet engine
      opts.snippets = { preset = "mini_snippets" }

      -- keymap
      opts.keymap = {
        preset = "super-tab",
        -- scroll docs
        ["<C-d>"] = { "scroll_documentation_down", "fallback" },
        ["<C-u>"] = { "scroll_documentation_up", "fallback" },
        -- toggle menu manually
        ["<C-space>"] = { "show", "show_documentation", "hide_documentation" },
        ["<C-e>"] = { "hide", "fallback" },
        -- navigate items (arrow-key style, since Tab is taken)
        ["<C-n>"] = { "select_next", "fallback" },
        ["<C-p>"] = { "select_prev", "fallback" },
      }

      -- sources with priority
      opts.sources = vim.tbl_deep_extend("force", opts.sources or {}, {
        default = { "lsp", "path", "snippets", "buffer" },
        providers = {
          lsp = {
            score_offset = 100,
          },
          snippets = {
            score_offset = 80,
          },
          path = {
            score_offset = 60,
          },
          buffer = {
            score_offset = 40,
            opts = {
              -- OPTION 1: all loaded buffers
              -- get_bufnrs = vim.api.nvim_list_bufs,
              -- OPTION 2: all loaded regular-file buffers
              -- get_bufnrs = function()
              --   return vim.tbl_filter(function(buf)
              --     return vim.bo[buf].buftype == "" -- regular file (not terminal, help, etc.)
              --       and vim.api.nvim_buf_is_loaded(buf) -- actually loaded in memory
              --   end, vim.api.nvim_list_bufs())
              -- end,
              -- OPTION 3: all regular files, but cap size to avoid lag on huge buffers
              get_bufnrs = function()
                return vim.tbl_filter(function(buf)
                  local max_size = 1024 * 1024 -- 1MB
                  return vim.bo[buf].buftype == ""
                    and vim.api.nvim_buf_is_loaded(buf)
                    and vim.api.nvim_buf_get_offset(buf, vim.api.nvim_buf_line_count(buf)) < max_size
                end, vim.api.nvim_list_bufs())
              end,
            },
          },
        },
      })

      -- show source labels + completion menu
      opts.completion = vim.tbl_deep_extend("force", opts.completion or {}, {
        menu = {
          draw = {
            columns = {
              { "kind_icon" },
              { "label", "label_description", gap = 1 },
              { "source_name" },
            },
          },
        },
        documentation = {
          auto_show = true,
          auto_show_delay_ms = 200,
        },
        ghost_text = { enabled = true },
      })
    end,
  },

  -- disable LuaSnip (undo our earlier override)
  { "L3MON4D3/LuaSnip", enabled = false },

  -- friendly-snippets provides the snippet collection
  {
    "rafamadriz/friendly-snippets",
  },

  -- mini.snippets engine
  {
    "nvim-mini/mini.snippets",
    enabled = true,
    dependencies = { "rafamadriz/friendly-snippets" },
    config = function()
      local mini_snippets = require("mini.snippets")
      mini_snippets.setup({
        snippets = {
          -- load friendly-snippets (VSCode format)
          mini_snippets.gen_loader.from_lang(),
          -- your custom snippets — use from_file with explicit lang
          mini_snippets.gen_loader.from_file(vim.fn.stdpath("config") .. "/snippets/python.json", { lang = "python" }),
        },
      })
    end,
  },
}
