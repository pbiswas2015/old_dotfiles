return {
  -- Explicit mason installs
  {
    "WhoIsSethDaniel/mason-tool-installer.nvim",
    opts = {
      ensure_installed = {
        -- lsp
        "bash-language-server",
        "json-lsp",
        "lua-language-server",
        "marksman",
        -- "pyright",
        "basedpyright",
        "stylua",
        "yaml-language-server",
        "tclint",
        "svls",
        "rust_hdl",

        -- linters
        "eslint_d",
        "jsonlint",
        "shellcheck",
        "yamllint",
        "verible",
        "vsg",
        "mypy",

        -- dap
        "bash-debug-adapter",
        "debugpy",
        "local-lua-debugger-vscode",
        "perl-debug-adapter",

        -- formatters
        "markdown-toc",
        "markdownlint-cli2",
        "prettierd",
        "ruff",
        "sqruff",
        "shfmt",
      },
    },
  },
}
