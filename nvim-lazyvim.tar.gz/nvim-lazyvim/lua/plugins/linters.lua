return {
  {
    "mfussenegger/nvim-lint",
    opts = {
      -- Event to trigger linters
      events = { "BufWritePost", "BufReadPost", "InsertLeave" },
      linters_by_ft = {
        bash = { "shellcheck" },
        -- python = { "ruff" },
        python = { "mypy" }, -- type checking
        yaml = { "yamllint" },
        json = { "jsonlint" },
        jsonc = { "eslint_d" },
        -- tcl = { "tclint" },
        tcl = { "nagelfar", "tclint" },
        verilog = { "verible-verilog-lint" },
        systemverilog = { "verible-verilog-lint" },
        vhdl = { "vsg" },
        -- Use the "*" filetype to run linters on all filetypes.
        -- ['*'] = { 'global linter' },
        -- Use the "_" filetype to run linters on filetypes that don't have other linters configured.
        -- ['_'] = { 'fallback linter' },
        -- ["*"] = { "typos" },
      },
      -- LazyVim extension to easily override linter options
      -- or add custom linters.
      ---@type table<string,table>
      linters = {
        -- -- Example of using selene only when a selene.toml file is present
        -- selene = {
        --   -- `condition` is another LazyVim extension that allows you to
        --   -- dynamically enable/disable linters based on the context.
        --   condition = function(ctx)
        --     return vim.fs.find({ "selene.toml" }, { path = ctx.filename, upward = true })[1]
        --   end,
        -- },
      },
    },
    config = function()
      local lint = require("lint")
      local nagelfar_path = vim.fn.expand("~/.local/share/nagelfar/nagelfar.tcl")

      lint.linters.nagelfar = {
        cmd = "tclsh",
        args = {
          nagelfar_path,
          "-quiet", -- suppress "Checking file..." line
          "-severity",
          "N", -- show all: Errors + Warnings + Notes
          "-2pass", -- better proc detection
        },
        stdin = false,
        stream = "stdout",
        ignore_exitcode = true,
        parser = function(output, bufnr)
          local diagnostics = {}
          local severity_map = {
            E = vim.diagnostic.severity.ERROR,
            W = vim.diagnostic.severity.WARN,
            N = vim.diagnostic.severity.HINT,
          }

          local current = nil
          for line in output:gmatch("[^\n]+") do
            -- match: "Line   2: W message"
            local lnum, sev, msg = line:match("^Line%s+(%d+):%s+(%a)%s+(.*)")
            if lnum then
              -- save previous:
              if current then
                table.insert(diagnostics, current)
              end
              current = {
                lnum = tonumber(lnum) - 1, -- neovim is 0-indexed
                col = 0,
                severity = severity_map[sev] or vim.diagnostic.severity.WARN,
                message = msg,
                source = "nagelfar",
              }
            elseif current and line:match("^%s+%S") then
              -- continuation line — append to message:
              current.message = current.message .. "\n" .. vim.trim(line)
            end
          end
          -- insert last diagnostic:
          if current then
            table.insert(diagnostics, current)
          end

          return diagnostics
        end,
      }

      -- run on file buffer enter, save and open: for tcl and python files
      vim.api.nvim_create_autocmd({ "BufWritePost", "BufReadPost", "BufEnter" }, {
        pattern = { "*.tcl", "*.py" },
        callback = function()
          vim.defer_fn(function()
            lint.try_lint()
          end, 100)
        end,
      })
    end,
  },
}
