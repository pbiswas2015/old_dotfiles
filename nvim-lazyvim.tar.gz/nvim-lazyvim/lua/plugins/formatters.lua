return {
  {
    "stevearc/conform.nvim",
    opts = {
      formatters_by_ft = {
        lua = { "stylua" },
        fish = { "fish_indent" },
        sh = { "shfmt" },
        python = {
          "ruff_format", -- format (replaces black)
          "ruff_fix", -- auto-fix lint issues
          -- "ruff"
        },
        tcl = { "tclfmt" },
        yaml = { "prettierd" }, -- or yamlfmt
        json = { "prettierd" }, -- or prettier
        jsonc = { "prettierd" }, -- JSON with comments
        sql = { "sqruff" },
        verilog = { "verible-verilog-format" },
        vsg = { "vsg" },
        systemverilog = { "verible-verilog-format" },
      },
      formatters = {
        verible_verilog_format = {
          prepend_args = { "--indent=2", "--assignment_statement_break=1" },
        },
      },
    },
  },
}
