return {
  {
    "jay-babu/mason-nvim-dap.nvim",
    opts = {
      -- Makes a best effort to setup the various debuggers with
      -- reasonable debug configurations
      automatic_installation = true,

      -- You can provide additional configuration to the handlers,
      -- see mason-nvim-dap README for more information
      handlers = {
        python = function() end,
      },
      ensure_installed = {
        -- Update this to ensure that you have the debuggers for the langs you want
        "python",
        "stylua",
        "bash",
      },
    },
  },

  -- extend nvim-dap — no config override, only add keys
  {
    "mfussenegger/nvim-dap",
    optional = true,
    keys = {
      { "<leader>dn", "<cmd>DapNew<cr>", desc = "Debug New" },
      {
        "<leader>dR",
        function()
          require("dap").restart()
        end,
        desc = "Restart",
      },
    },
  },

  -- dap-python in its own spec — safe, doesn't touch nvim-dap config
  {
    "mfussenegger/nvim-dap-python",
    dependencies = { "mfussenegger/nvim-dap" },
    ft = "python",
    -- stylua: ignore
    keys = {
      { "<leader>dPt", function() require("dap-python").test_method() end, desc = "Debug Method", ft = "python" },
      { "<leader>dPc", function() require("dap-python").test_class() end, desc = "Debug Class", ft = "python" },
    },
    config = function()
      -- require("dap-python").setup("debugpy-adapter")
      require("dap-python").setup("python3")
      require("dap-python").test_runner = "pytest"
    end,
  },

  -- dap-ui listeners — extend via config, not replace
  {
    "rcarriga/nvim-dap-ui",
    optional = true,
    config = function(_, opts)
      local dap = require("dap")
      local dapui = require("dapui")
      dapui.setup(opts)

      dap.listeners.after.event_initialized["dapui_config"] = function()
        dapui.open()
      end
      dap.listeners.before.event_terminated["dapui_config"] = function()
        dapui.close()
      end
      dap.listeners.before.event_exited["dapui_config"] = function()
        dapui.close()
      end
    end,
  },

  {
    "nvim-neotest/neotest-python",
  },

  {
    "nvim-neotest/neotest",
    optional = true,
    dependencies = {
      "nvim-neotest/neotest-python",
    },
    opts = function(_, opts)
      if not opts.adapters then
        opts.adapters = {}
      end
      table.insert(
        opts.adapters,
        require("neotest-python")({
          runner = "pytest",
          args = { "--capture=no", "-vv" },
          dap = { justMyCode = false },
        })
      )
    end,
    keys = {
      {
        "<leader>ty",
        function()
          require("neotest").summary.toggle()
        end,
        desc = "Test summary toggle (Neotest)",
      },
    },
  },

  -- molten-nvim — jupyter notebooks:
  -- molten-nvim: run cells, see plots inline in terminal
  -- Requires: pip install pynvim jupyter_client cairosvg pnglatex plotly kaleido
  {
    "benlubas/molten-nvim",
    build = ":UpdateRemotePlugins",
    dependencies = {
      "3rd/image.nvim", -- for image output (optional)
    },
    init = function()
      -- find python3 path
      vim.g.python3_host_prog = vim.fn.exepath("python3")

      vim.g.molten_image_provider = "image.nvim"
      -- output window settings:
      vim.g.molten_output_win_max_height = 15
      vim.g.molten_output_win_style = "minimal"
      -- show auto-pop output window
      vim.g.molten_auto_open_output = true
      vim.g.molten_wrap_output = true
      -- show output as virtual text instead
      vim.g.molten_virt_text_output = false
      -- align virtual text properly
      vim.g.molten_virt_lines_off_by_1 = true

      -- auto-hide float when cursor moves
      -- vim.api.nvim_create_autocmd("CursorMoved", {
      --   callback = function()
      --     pcall(vim.cmd, "MoltenHideOutput")
      --   end,
      -- })
    end,
    config = function()
      vim.keymap.set("n", "<leader>mi", ":MoltenInit<cr>", { desc = "Init molten kernel" })
      vim.keymap.set("n", "<leader>mr", ":MoltenEvaluateLine<cr>", { desc = "Eval line (molten)" })
      vim.keymap.set("v", "<leader>mr", ":<C-u>MoltenEvaluateVisual<cr>", { desc = "Eval selection (molten)" })
      vim.keymap.set(
        "n",
        "<leader>mo",
        ":MoltenEnterOutput<cr>",
        { silent = true, desc = "Enter output window (molten)" }
      )
      vim.keymap.set("n", "<leader>mh", ":MoltenHideOutput<cr>", { silent = true, desc = "Hide output (molten)" })
    end,
  },

  -- jupytext: seamless .ipynb <-> .py conversion
  {
    "GCBallesteros/jupytext.nvim",
    -- # %% cell markers
    opts = { style = "percent", output_extension = "auto" },
  },
}
