return {

  -- claude code integration
  {
    "coder/claudecode.nvim",
    dependencies = { "folke/snacks.nvim" },
    -- loads after UI, still automatic
    event = "VeryLazy",
    config = function()
      -- require("claudecode").setup()
      require("claudecode").setup({
        -- Point to local installation
        -- terminal_cmd = "~/.local/bin/claude",
        -- auto-find binary
        terminal_cmd = vim.fn.exepath("claude"),
        auto_attach = true,
        split_side = "right",
        split_width_pct = 0.35,
      })
    end,
  },

  -- fzf-lua integration — add files to claude context via fzf:
  {
    "pittcat/claude-fzf.nvim",
    event = "VeryLazy",
    dependencies = { "ibhagwan/fzf-lua", "coder/claudecode.nvim" },
    config = function()
      require("claude-fzf").setup({
        auto_context = true,
        batch_size = 10,
        auto_open_terminal = true,
        notifications = {
          enabled = false,
          use_snacks = false,
        },
        logging = {
          level = "ERROR", -- only show errors
          file_logging = false, -- disable file logging
          console_logging = false, -- disable console logging
        },
      })
    end,
    keys = {
      { "<leader>aF", "<cmd>ClaudeFzfFiles<cr>", desc = "Claude add files (fzf)" },
      { "<leader>ag", "<cmd>ClaudeFzfGrep<cr>", desc = "Claude add grep (fzf)" },
      { "<leader>aB", "<cmd>ClaudeFzfBuffers<cr>", desc = "Claude add buffers (fzf)" },
      { "<leader>ad", "<cmd>ClaudeFzfDirectory<cr>", desc = "Claude add directory (fzf)" },
    },
  },
}
