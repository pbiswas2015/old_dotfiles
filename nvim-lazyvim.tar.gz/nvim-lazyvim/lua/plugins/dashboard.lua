return {
  {
    "nvim-mini/mini.starter",
    opts = function()
      local pad = string.rep(" ", 22)
      local new_section = function(name, action, section)
        return { name = name, action = action, section = pad .. section }
      end
      local starter = require("mini.starter")
      return {
        header = table.concat({
          "            ██╗      █████╗ ███████╗██╗   ██╗██╗   ██╗██╗███╗   ███╗          Z",
          "            ██║     ██╔══██╗╚══███╔╝╚██╗ ██╔╝██║   ██║██║████╗ ████║      Z    ",
          "            ██║     ███████║  ███╔╝  ╚████╔╝ ██║   ██║██║██╔████╔██║   z       ",
          "            ██║     ██╔══██║ ███╔╝    ╚██╔╝  ╚██╗ ██╔╝██║██║╚██╔╝██║ z         ",
          "            ███████╗██║  ██║███████╗   ██║    ╚████╔╝ ██║██║ ╚═╝ ██║           ",
          "            ╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═══╝  ╚═╝╚═╝     ╚═╝           ",
          "                                     pbiswas                                   ",
        }, "\n"),
        items = {
          -- starter.sections.recent_files(10, true, true), -- Recent 10
          new_section("Find file", LazyVim.pick(), "Files"),
          new_section("New file", "ene | startinsert", "Built-in"),
          new_section("Recent files", LazyVim.pick("oldfiles"), "Files"),
          new_section("Grep text", LazyVim.pick("live_grep"), "Files"),
          new_section("Config", LazyVim.pick.config_files(), "Config"),
          new_section("Session Restore", [[lua require("persistence").load()]], "Session"),
          new_section("Extras", "LazyExtras", "Config"),
          new_section("Lazy", "Lazy", "Config"),
          new_section("Quit", "qall", "Built-in"),
        },
        content_hooks = {
          starter.gen_hook.adding_bullet(" ▶ "),
          starter.gen_hook.aligning("center", "center"),
        },
      }
    end,
  },
}
