return {
  {
    "folke/which-key.nvim",
    opts = {
      defaults = {
        ["<leader>h"] = { name = "+hw" },
      },
      preset = "modern",
      plugins = {
        marks = true, -- shows a list of your marks on ' and `
        registers = true, -- shows your registers on " in NORMAL or <C-r> in INSERT mode
        -- the presets plugin, adds help for a bunch of default keybindings in Neovim
        -- No actual key bindings are created
        spelling = {
          enabled = true, -- enabling this will show WhichKey when pressing z= to select spelling suggestions
          suggestions = 20, -- how many suggestions should be shown in the list?
        },
      },
    },
    config = function(_, opts)
      local wk = require("which-key")
      wk.add({
        { "<leader>hf", "<cmd>ConformFmt<cr>", desc = "Format (Verible)" },
        { "<leader>hl", "<cmd>Lint<cr>", desc = "Lint (Verible)" },
        { "<leader>hd", "<cmd>lua vim.lsp.buf.definition()<cr>", desc = "Go to Definition" },
        -- mode = "n",
      })
    end,
  },
}
