return {
  -- auto tag generation
  {
    "ludovicchabant/vim-gutentags",
    config = function()
      vim.g.gutentags_cache_dir = vim.fn.expand("~/.cache/ctags")
      vim.g.gutentags_generate_on_new = true
      vim.g.gutentags_generate_on_missing = true
      vim.g.gutentags_generate_on_write = true
      vim.g.gutentags_ctags_extra_args = {
        "--fields=+ailmnS",
        "--extras=+q",
        "--exclude=.git",
        "--exclude=node_modules",
      }
      vim.g.gutentags_file_list_command = "fd --type f --color=never"
    end,
  },

  -- tag sidebar
  {
    "liuchengxu/vista.vim",
    config = function()
      vim.g.vista_default_executive = "ctags"
      vim.g.vista_fallback_executive = "nvim_lsp"
      -- disable cursor echo entirely
      vim.g.vista_echo_cursor = 0
      -- vim.g.vista_echo_cursor_strategy = "floating_win"
      -- vim.g.vista_echo_cursor_strategy = "scroll"
      vim.g.vista_no_mappings = 1
      vim.keymap.set("n", "<leader>vt", ":Vista!!<cr>", { desc = "Vista window open/close toggle", silent = true })
      vim.keymap.set("n", "<leader>vc", ":Vista ctags<cr>", { desc = "Change o ctags in Vista", silent = true })
      vim.keymap.set("n", "<leader>vl", ":Vista nvim_lisp<cr>", { desc = "Change to LSP in Vista", silent = true })
      vim.keymap.set("n", "<leader>vj", ":Vista show<cr>", { desc = "Jump to nearest tag in Vista", silent = true })
      vim.keymap.set(
        "n",
        "<leader>vf",
        ":FzfLua tags<cr>",
        { desc = "Tag fuzzy find (Vista using Fzf-lua)", silent = true }
      )
      vim.keymap.set(
        "n",
        "<leader>vF",
        ":FzfLua btags<cr>",
        { desc = "Tag fuzzy find in buffer (Vista using Fzf-lua)", silent = true }
      )
    end,
  },
}
