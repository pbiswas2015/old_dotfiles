return {
  {
    "neovim/nvim-lspconfig",
    opts = {
      servers = {
        lua_ls = {
          settings = {
            Lua = {
              diagnostics = {
                globals = { "vim" },
              },
              workspace = {
                library = {
                  vim.fn.stdpath("data") .. "/lazy/",
                  vim.fn.stdpath("config") .. "/lua",
                },
                checkThirdParty = false,
              },
              telemetry = { enable = false },
            },
          },
        },
        ruff = {
          keys = {
            {
              "<leader>co",
              LazyVim.lsp.action["source.organizeImports"],
              desc = "Organize Imports",
            },
          },
          on_attach = function(client, bufnr)
            -- disable hover — basedpyright handles it:
            client.server_capabilities.hoverProvider = false
          end,
          -- force UTF-16 to match basedpyright:
          capabilities = {
            offsetEncoding = { "utf-16" },
          },
        },
        svls = {
          -- Verilog/SystemVerilog LSP
          filetypes = { "verilog", "systemverilog" },
          settings = {
            svls = {
              globalStoragePath = vim.fn.stdpath("cache") .. "/svls",
            },
          },
        },
        basedpyright = {
          settings = {
            basedpyright = {
              analysis = {
                typeCheckingMode = "standard",
                autoSearchPaths = true,
                diagnosticMode = "workspace",
                useLibraryCodeForTypes = true,
                inlayHints = {
                  variableTypes = true,
                  returnTypes = true,
                  parameterTypes = true,
                  callArgumentNames = true,
                },
              },
            },
          },
        },
      },
    },
  },
}
