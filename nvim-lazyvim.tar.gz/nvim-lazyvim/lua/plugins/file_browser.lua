return {
  -- {
  --   -- file browser
  --   "nvim-telescope/telescope-file-browser.nvim",
  --   keys = {
  --     {
  --       "<leader>fd",
  --       ":Telescope file_browser path=%:p:h=%:p:h<cr>",
  --       desc = "Browse Files/Directories",
  --     },
  --   },

  --   config = function()
  --     require("telescope").load_extension("file_browser")
  --   end,
  -- },

  {
    "ibhagwan/fzf-lua",
    keys = {
      -- add a keymap to browse plugin files
      -- stylua: ignore
      {
        "<leader>fP",
        function() require("fzf-lua").files({ cwd = require("lazy.core.config").options.root }) end,
        desc = "Find Plugin File",
      },
    },
    opts = {
      fzf_opts = {
        ["--pointer"] = "▮", -- Cursor style
        ["--layout"] = "reverse", -- List at top
      },
      defaults = {
        file_ignore_patterns = { ".git/", "%.pyc" },
      },
      winopts = {
        preview = {
          vertical = "down:60%", -- Preview layout
        },
      },
    },
    init = function()
      -- Conditional ui.select
      local orig_select = vim.ui.select
      vim.ui.select = function(items, opts, on_choice)
        -- Skip fzf-lua for DAP configs
        if opts and (opts.kind == "configuration" or string.find(opts.prompt or "", "config")) then
          return orig_select(items, opts, on_choice) -- Default DAP select
        end
        -- fzf-lua for everything else
        require("fzf-lua").fzf_ui_select(items, opts, on_choice)
      end
    end,
  },

  -- {
  --   "stevearc/oil.nvim",
  --   ---@module 'oil'
  --   ---@type oil.SetupOpts
  --   opts = {},
  --   -- Optional dependencies
  --   dependencies = { { "nvim-mini/mini.icons", opts = {} } },
  --   -- dependencies = { "nvim-tree/nvim-web-devicons" }, -- use if you prefer nvim-web-devicons
  --   -- Lazy loading is not recommended because it is very tricky to make it work correctly in all situations.
  --   lazy = false,
  -- },
  -- lua/plugins/oil.lua

  -- disable neo-tree if LazyVim enabled it
  { "nvim-neo-tree/neo-tree.nvim", enabled = false },

  -- oil
  {
    "stevearc/oil.nvim",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    -- stylua ignore
    keys = {
      { "-", "<cmd>Oil<cr>", desc = "Open Parent Directory" },
      { "<leader>fo", "<cmd>Oil<cr>", desc = "Explorer (Oil)" },
      {
        "<leader>fO",
        function()
          require("oil").open_float()
        end,
        desc = "Explorer Float (Oil)",
      },
    },
    opts = {
      default_file_explorer = true, -- replace netrw
      view_options = {
        show_hidden = true,
      },
      columns = {
        "icon",
        -- "permissions",
        -- "size",
        -- "mtime",
      },
      keymaps = {
        ["g?"] = "actions.show_help",
        ["<CR>"] = "actions.select",
        ["-"] = "actions.parent",
        ["_"] = "actions.open_cwd",
        ["`"] = "actions.cd",
        ["~"] = "actions.tcd",
        ["gs"] = "actions.change_sort",
        ["gx"] = "actions.open_external",
        ["g."] = "actions.toggle_hidden",
        ["q"] = "actions.close",
      },
      float = {
        padding = 2,
        max_width = 80,
        max_height = 30,
      },
    },
  },
}
