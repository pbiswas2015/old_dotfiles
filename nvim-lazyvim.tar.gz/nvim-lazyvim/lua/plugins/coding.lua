return {
  -- Improves comment syntax, lets Neovim handle multiple types of comments for a single language,
  -- and relaxes rules for uncommenting.
  {
    "folke/ts-comments.nvim",
    event = "VeryLazy",
    opts = {},
  },

  -- Configures LuaLS to support auto-completion and type checking
  -- while editing your Neovim configuration
  {
    "folke/lazydev.nvim",
    ft = "lua",
    cmd = "LazyDev",
    opts = {
      library = {
        { path = "${3rd}/luv/library", words = { "vim%.uv" } },
        { path = "LazyVim", words = { "LazyVim" } },
        { path = "snacks.nvim", words = { "Snacks" } },
        { path = "lazy.nvim", words = { "LazyVim" } },
      },
    },
  },

  -- Extends the a & i text objects, this adds the ability to select arguments,
  -- function calls, text within quotes and brackets, and to repeat those selections
  -- to select an outer text object.
  {
    "nvim-mini/mini.ai",
    event = "VeryLazy",
    opts = function()
      local ai = require("mini.ai")
      return {
        n_lines = 500,
        custom_textobjects = {
          o = ai.gen_spec.treesitter({ -- code block
            a = { "@block.outer", "@conditional.outer", "@loop.outer" },
            i = { "@block.inner", "@conditional.inner", "@loop.inner" },
          }),
          f = ai.gen_spec.treesitter({ a = "@function.outer", i = "@function.inner" }), -- function
          c = ai.gen_spec.treesitter({ a = "@class.outer", i = "@class.inner" }), -- class
          t = { "<([%p%w]-)%f[^<%w][^<>]->.-</%1>", "^<.->().*()</[^/]->$" }, -- tags
          d = { "%f[%d]%d+" }, -- digits
          e = { -- Word with case
            { "%u[%l%d]+%f[^%l%d]", "%f[%S][%l%d]+%f[^%l%d]", "%f[%P][%l%d]+%f[^%l%d]", "^[%l%d]+%f[^%l%d]" },
            "^().*()$",
          },
          g = LazyVim.mini.ai_buffer, -- buffer
          u = ai.gen_spec.function_call(), -- u for "Usage"
          U = ai.gen_spec.function_call({ name_pattern = "[%w_]" }), -- without dot in function name
        },
      }
    end,
    config = function(_, opts)
      require("mini.ai").setup(opts)
      LazyVim.on_load("which-key.nvim", function()
        vim.schedule(function()
          LazyVim.mini.ai_whichkey(opts)
        end)
      end)
    end,
  },

  -- colorful delimiters
  {
    "HiPhish/rainbow-delimiters.nvim",
    event = "BufReadPost",
    dependencies = { "nvim-treesitter/nvim-treesitter" },
    config = function()
      local rd = require("rainbow-delimiters")
      vim.g.rainbow_delimiters = {
        blacklist = { "tcl" }, --  Disable for TCL
        strategy = {
          [""] = rd.strategy["global"],
          vim = rd.strategy["local"],
        },
        query = {
          [""] = "rainbow-delimiters",
          lua = "rainbow-blocks",
        },
        priority = {
          [""] = 110,
          lua = 210,
        },
        highlight = {
          "RainbowDelimiterRed",
          "RainbowDelimiterYellow",
          "RainbowDelimiterBlue",
          "RainbowDelimiterOrange",
          "RainbowDelimiterGreen",
          "RainbowDelimiterViolet",
          "RainbowDelimiterCyan",
        },
      }
    end,
  },

  -- aerial — symbol outline:
  {
    "stevearc/aerial.nvim",
    opts = {
      backends = { "treesitter", "lsp", "ctags" },
      filter_kind = {
        "Class",
        "Constructor",
        "Enum",
        "Function",
        "Interface",
        "Method",
        "Module",
        "Struct",
      },
      layout = {
        default_direction = "right",
        placement = "edge",
        min_width = 30,
      },
    },
    keys = {
      { "<leader>cs", "<cmd>AerialToggle<cr>", desc = "Aerial toggle" },
    },
  },

  -- undo tree: visual undo history
  {
    "mbbill/undotree",
    cmd = "UndotreeToggle",
    keys = {
      { "<leader>uu", "<cmd>UndotreeToggle<cr>", desc = "Undo tree toggle" },
    },
    init = function()
      vim.g.undotree_WindowLayout = 2 -- tree on left, diff below
      vim.g.undotree_SplitWidth = 35
      vim.g.undotree_SetFocusWhenToggle = 1 -- auto-focus on open
      vim.g.undotree_ShortIndicators = 1
    end,
  },

  -- nvim-ufo: better folding with LSP/treesitter
  {
    "kevinhwang91/nvim-ufo",
    dependencies = { "kevinhwang91/promise-async" },
    event = "BufReadPost",
    opts = {
      -- use LSP first, fall back to treesitter, then indent
      provider_selector = function(_, filetype, _)
        local lsp_ft = { "python", "lua", "c", "bash", "json", "yaml", "typescript", "javascript", "tcl" }
        if vim.tbl_contains(lsp_ft, filetype) then
          return { "lsp", "treesitter" }
        end
        return { "treesitter", "indent" }
      end,
      -- show line count in fold
      fold_virt_text_handler = function(virtText, lnum, endLnum, width, truncate)
        local newVirtText = {}
        local suffix = ("  %d lines"):format(endLnum - lnum)
        local sufWidth = vim.fn.strdisplaywidth(suffix)
        local targetWidth = width - sufWidth
        local curWidth = 0
        for _, chunk in ipairs(virtText) do
          local chunkText = chunk[1]
          local chunkWidth = vim.fn.strdisplaywidth(chunkText)
          if targetWidth > curWidth + chunkWidth then
            table.insert(newVirtText, chunk)
          else
            chunkText = truncate(chunkText, targetWidth - curWidth)
            local hlGroup = chunk[2]
            table.insert(newVirtText, { chunkText, hlGroup })
            chunkWidth = vim.fn.strdisplaywidth(chunkText)
            if curWidth + chunkWidth < targetWidth then
              suffix = suffix .. (" "):rep(targetWidth - curWidth - chunkWidth)
            end
            break
          end
          curWidth = curWidth + chunkWidth
        end
        table.insert(newVirtText, { suffix, "MoreMsg" })
        return newVirtText
      end,
    },
    config = function(_, opts)
      -- required fold settings
      vim.o.foldcolumn = "1"
      vim.o.foldlevel = 99 -- open all folds by default
      vim.o.foldlevelstart = 99
      vim.o.foldenable = true

      require("ufo").setup(opts)

      -- keymaps
      vim.keymap.set("n", "zR", require("ufo").openAllFolds, { desc = "Open all folds" })
      vim.keymap.set("n", "zM", require("ufo").closeAllFolds, { desc = "Close all folds" })
      vim.keymap.set("n", "zr", require("ufo").openFoldsExceptKinds, { desc = "Open folds except kinds" })
      vim.keymap.set("n", "zm", require("ufo").closeFoldsWith, { desc = "Close folds with" })
      -- peek fold contents without opening
      vim.keymap.set("n", "zK", function()
        local winid = require("ufo").peekFoldedLinesUnderCursor()
        if not winid then
          vim.lsp.buf.hover()
        end
      end, { desc = "Peek fold / hover" })
    end,
  },

  -- litee core:
  -- interactive call hierarchy tree
  {
    "ldelossa/litee.nvim",
    event = "LspAttach",
    config = function()
      require("litee.lib").setup({
        tree = {
          icon_set = "codicons", -- needs nerd font
        },
        panel = {
          orientation = "right", -- panel on right side
          panel_size = 35,
        },
        notify = { enabled = false },
      })
    end,
  },

  -- calltree:
  {
    "ldelossa/litee-calltree.nvim",
    event = "LspAttach",
    dependencies = { "ldelossa/litee.nvim" },
    config = function()
      require("litee.calltree").setup({
        -- open as sidebar panel
        on_open = "popout",
        indent_guides = true,
        icon_set = "codicons",
        tree_width = 35,
        no_hls = false,
        map_resize_keys = false,
      })

      -- keymaps:
      local k = vim.keymap.set
      local o = { silent = true }
      local function m(key, cmd, desc)
        k("n", key, cmd, vim.tbl_extend("force", o, { desc = desc }))
      end

      -- Trigger (global, from anywhere)
      -- Used by FzfLua instead
      -- m("<leader>ci", vim.lsp.buf.incoming_calls, "Calltree incoming calls")
      -- m("<leader>co", vim.lsp.buf.outgoing_calls, "Calltree outgoing calls")

      -- Panel / Window
      m("<leader>chp", "<cmd>LTPanel<cr>", "Calltree panel toggle (deep)")
      m("<leader>chc", "<cmd>LTOpenToCalltree<cr>", "Calltree open panel (deep)")
      m("<leader>chx", "<cmd>LTCloseCalltree<cr>", "Calltree close+clear (deep)")
    end,
  },

  -- diff view
  {
    "sindrets/diffview.nvim",
    -- dependencies = { "nvim-tree/nvim-web-devicons" }, -- optional, for file icons
    cmd = { "DiffviewOpen", "DiffviewFileHistory" }, -- lazy-load on command
    keys = {
      { "<leader>gd", "<cmd>DiffviewOpen<cr>", desc = "Git Diff" },
      { "<leader>gh", "<cmd>DiffviewFileHistory %<cr>", desc = "File History" },
      { "<leader>gH", "<cmd>DiffviewFileHistory<cr>", desc = "Branch History" },
      { "<leader>gq", "<cmd>DiffviewClose<cr>", desc = "Close Diffview" },
    },
    opts = {
      enhanced_diff_hl = true, -- better diff highlighting via treesitter
      view = {
        default = { layout = "diff2_horizontal" }, -- side-by-side
        merge_tool = {
          layout = "diff3_horizontal", -- 3-way merge view
          disable_diagnostics = true,
        },
      },
      file_panel = {
        listing_style = "tree", -- "list" or "tree"
        win_config = { width = 35 },
      },
    },
  },
}
