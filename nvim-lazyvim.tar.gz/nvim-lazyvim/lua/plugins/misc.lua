return {
  {
    "linux-cultist/venv-selector.nvim",
    cmd = "VenvSelect",
    opts = {
      options = {
        notify_user_on_venv_activation = true,
      },
      settings = {
        search = {
          conda_envs = { command = "fd bin/python$ ~/miniforge3/envs --type f -L" },
          mamba_envs = { command = "fd bin/python$ ~/micromamba/envs --type f -L" },
        },
        -- hooks = {
        --   on_venv_activate = function(venv_path)
        --     -- update shell PATH so :! commands also work
        --     local bin_dir = venv_path:match("(.*/)")
        --     vim.env.PATH = bin_dir .. ":" .. vim.env.PATH
        --     vim.env.CONDA_PREFIX = venv_path:match("(.+)/bin/")
        --     vim.env.VIRTUAL_ENV = venv_path:match("(.+)/bin/")
        --   end,
        -- },
      },
    },
    --  Call config for Python files and load the cached venv automatically
    ft = "python",
    keys = { { "<leader>cv", "<cmd>:VenvSelect<cr>", desc = "Select VirtualEnv", ft = "python" } },
  },

  {
    "ThePrimeagen/harpoon",
    keys = {
      {
        "<leader>hm",
        function()
          require("harpoon"):list():add()
        end,
        desc = "Harpoon File",
      },
      {
        "<leader>hq",
        function()
          local harpoon = require("harpoon")
          harpoon.ui:toggle_quick_menu(harpoon:list())
        end,
        desc = "Harpoon Quick Menu",
      },
      {
        "<leader>hp",
        function()
          local harpoon = require("harpoon")
          harpoon.ui:nav_prev()
        end,
        desc = "Navigate to previous harpoon file",
      },
      {
        "<leader>hn",
        function()
          local harpoon = require("harpoon")
          harpoon.ui:nav_next()
        end,
        desc = "Navigate to next harpoon file",
      },
      {
        "<leader>hr",
        function()
          require("harpoon"):list():remove()
        end,
        desc = "Remove harpoon/mark",
      },
      {
        "<leader>hc",
        function()
          require("harpoon"):list():clear()
        end,
        desc = "Remove all harpoon/mark",
      },
    },
  },

  -- lua/plugins/align.lua
  -- ga=          -- align around = the visual selection
  -- gaip=        -- align inner paragraph around =
  -- gaa,         -- align around , (current line)
  --
  -- -- with modifiers (interactive, press keys before delimiter)
  -- ga           -- start
  --   s          -- split modifier
  --   j          -- justify modifier
  --   m          -- merge modifier
  --   then =     -- delimiter

  {
    {
      "nvim-mini/mini.align",
      keys = {
        { "ga", mode = { "n", "v" }, desc = "Align" },
        { "gA", mode = { "n", "v" }, desc = "Align with Preview" },
      },
      opts = {
        mappings = {
          start = "ga", -- align (no preview)
          start_with_preview = "gA", -- align with live preview
        },
      },
    },
  },
}
