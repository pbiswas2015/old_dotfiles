-- Autocmds are automatically loaded on the VeryLazy event
-- Default autocmds that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/autocmds.lua
--
-- Add any additional autocmds here
-- with `vim.api.nvim_create_autocmd`
--
-- Or remove existing autocmds by their group name (which is prefixed with `lazyvim_` for the defaults)
-- e.g. vim.api.nvim_del_augroup_by_name("lazyvim_wrap_spell")

-- fix wq not quting current file/buffer
-- Smart :wq - save + close buffer always
vim.api.nvim_create_user_command("WQ", function()
  -- Only save if the buffer is a normal file
  if vim.bo.buftype == "" then
    vim.cmd("write")
  end
  -- return only normal buffers
  local bufs = vim.tbl_filter(function(b)
    return vim.bo[b].buflisted and vim.bo[b].buftype == ""
  end, vim.api.nvim_list_bufs())
  -- quit is count of normal buffers is 1
  if #bufs <= 1 then
    vim.cmd("quit")
  else
    local curent_buf = vim.api.nvim_get_current_buf()
    vim.cmd("bnext")
    vim.cmd("silent! bdelete" .. curent_buf)
  end
end, {
  nargs = 0,
  force = true,
})

-- Also alias lowercase (workaround)
vim.cmd([[
  cabbrev wq WQ
  cabbrev x WQ
]])

-- add keymaps specific to vista buffer
vim.api.nvim_create_autocmd("FileType", {
  pattern = { "vista", "vista_kind" },
  callback = function()
    local opts = { buffer = true, silent = true, noremap = true }
    vim.keymap.set("n", "<CR>", ":<C-u>call vista#cursor#FoldOrJump()<CR>", opts)
    vim.keymap.set("n", "<2-LeftMouse>", ":<C-u>call vista#cursor#FoldOrJump()<CR>", opts)
    vim.keymap.set("n", "s", ":<C-u>call vista#Sort()<CR>", opts)
    vim.keymap.set("n", "p", ":<C-u>call vista#cursor#TogglePreview()<CR>", opts)
  end,
})
