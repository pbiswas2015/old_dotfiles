-- Options are automatically loaded before lazy.nvim startup
-- Default options that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/options.lua
-- Add any additional options here

-- bar at top of every window
-- shows path to file
-- vim.opt.winbar = "%=%m %f"

-- LSP Server to use for Python.
-- Set to "basedpyright" to use basedpyright instead of pyright.
vim.g.lazyvim_python_lsp = "basedpyright"
-- Set to "ruff_lsp" to use the old LSP implementation version.
vim.g.lazyvim_python_ruff = "ruff"

-- ~/.config/nvim/lua/config/options.lua
-- fix for gg not going to top of file
-- vim.g.noice_focus = false -- Disable focus stealing

-- Set startofline on (Vim default, fixes gg behavior)
vim.opt.startofline = true
