-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here

-- gf → new tab (replaces current buffer with tab)
-- vim.keymap.set("n", "gf", "<Cmd>tabedit <cfile><CR>", { desc = "Goto file (tab)" })

-- Bonus: <C-gf> → vertical split
-- vim.keymap.set("n", "<C-g>f", "<Cmd>vsplit <cfile><CR>", { desc = "Goto file (vsplit)" })

-- add $ { } to valid filename characters:
vim.opt.isfname:append({ "$", "{", "}" })

-- override gf to expand env vars and open in new tab:
vim.keymap.set("n", "gf", function()
  local path = vim.fn.expand("<cfile>") -- get path under cursor

  -- expand ~ first:
  path = path:gsub("^~", os.getenv("HOME") or "~")

  -- manually resolve ${VAR} using os.getenv:
  local expanded = path:gsub("%${(%w+)}", function(var)
    return os.getenv(var) or ("${" .. var .. "}")
  end)

  -- also resolve $VAR (without braces):
  expanded = expanded:gsub("%$(%w+)", function(var)
    return os.getenv(var) or ("$" .. var)
  end)

  print("expanded: " .. expanded)

  if vim.fn.filereadable(expanded) == 1 then
    vim.cmd("tabedit " .. vim.fn.fnameescape(expanded))
  elseif vim.fn.isdirectory(expanded) == 1 then
    vim.cmd("tabedit " .. vim.fn.fnameescape(expanded))
  else
    vim.notify("File not found: " .. expanded, vim.log.levels.WARN)
  end
end, { noremap = true, silent = true, desc = "gf with env var expansion in new tab" })

-- ctags nagivation
--~/.config/nvim/lua/keymaps.lua
-- jump to definition:
vim.keymap.set("n", "<C-]>", "<C-]>", { desc = "Jump to tag" })
-- jump back:
vim.keymap.set("n", "<C-t>", "<C-t>", { desc = "Jump back" })
-- open in split:
vim.keymap.set("n", "<C-w>]", "<C-w>]", { desc = "Tag in split" })
-- open in vsplit:
vim.keymap.set("n", "<C-w>}", "<C-w>}", { desc = "Tag in preview" })
-- cycle multiple matches:
vim.keymap.set("n", "]t", ":tnext<CR>", { desc = "Next tag match" })
vim.keymap.set("n", "[t", ":tprev<CR>", { desc = "Prev tag match" })
-- list all matches:
vim.keymap.set("n", "<leader>ts", ":tselect<CR>", { desc = "Select tag" })

-- call hierarchy: quick lookup → fzf-lua (instant, always current):
vim.keymap.set(
  "n",
  "<leader>chi",
  "<cmd>FzfLua lsp_incoming_calls<cr>",
  { silent = true, desc = "Incoming calls (quick)" }
)
vim.keymap.set(
  "n",
  "<leader>cho",
  "<cmd>FzfLua lsp_outgoing_calls<cr>",
  { silent = true, desc = "Outgoing calls (quick)" }
)
