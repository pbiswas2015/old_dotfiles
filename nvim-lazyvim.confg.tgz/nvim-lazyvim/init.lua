-- bootstrap lazy.nvim, LazyVim and your plugins
require("config.lazy")

-- disable loading of providers
vim.g.loaded_python3_provider = 0
vim.g.loaded_python_provider = 0 -- Python 2
vim.g.loaded_perl_provider = 0
vim.g.loaded_ruby_provider = 0

-- start neovide always in home directory
-- only when NVIM_WSL_GUI is set:
--   which is set in windows only
--   this applies to neovide running in windows and neovim in WSL
if vim.g.neovide and os.getenv("NVIM_WSL_GUI") == "windows" then
  local home = vim.loop.os_homedir()
  vim.api.nvim_set_current_dir(home)
  -- Update the env PATH
  vim.env.PATH = "/home/pbiswas/.local/bin:" .. vim.env.PATH
  vim.env.PATH = "/usr/local/cuda-12.8/bin:" .. vim.env.PATH
  vim.env.PATH = "/home/linuxbrew/.linuxbrew/bin:" .. vim.env.PATH
  vim.env.PATH = "/home/linuxbrew/.linuxbrew/sbin:" .. vim.env.PATH
  vim.env.PATH = "/home/pbiswas/.cargo/bin:" .. vim.env.PATH
end
