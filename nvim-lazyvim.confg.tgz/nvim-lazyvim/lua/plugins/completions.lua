return {
  {
    "saghen/blink.cmp",
    enabled = true,
    opts = {
      keymap = {
        preset = "super-tab",
      },
      sources = {
        enable = true,
        default = { "lsp", "path", "buffer" },
      },
    },
  },
}
