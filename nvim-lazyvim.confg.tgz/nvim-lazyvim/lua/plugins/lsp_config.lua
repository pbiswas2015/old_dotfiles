return {
  {
    "neovim/nvim-lspconfig",
    opts = {
      servers = {
        lua_ls = {
          settings = {
            Lua = {
              diagnostics = {
                globals = { "vim" },
              },
              workspace = {
                library = {
                  vim.fn.stdpath("data") .. "/lazy/",
                  vim.fn.stdpath("config") .. "/lua",
                },
                checkThirdParty = false,
              },
              telemetry = { enable = false },
            },
          },
        },
        ruff_lsp = {
          keys = {
            {
              "<leader>co",
              LazyVim.lsp.action["source.organizeImports"],
              desc = "Organize Imports",
            },
          },
        },
        svls = {
          -- Verilog/SystemVerilog LSP
          filetypes = { "verilog", "systemverilog" },
          settings = {
            svls = {
              globalStoragePath = vim.fn.stdpath("cache") .. "/svls",
            },
          },
        },
      },
    },
  },
}
